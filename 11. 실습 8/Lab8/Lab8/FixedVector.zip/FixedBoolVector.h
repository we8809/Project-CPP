#pragma once

#include <iostream>
#include <bitset>
#include "FixedVector.h"

namespace lab8
{
	template <size_t N>
	class FixedVector<bool, N>
	{
	public:
		FixedVector();
		~FixedVector() = default;
		
		bool Add(const bool& data);
		bool Remove(bool findData);
		const bool& Get(unsigned int idx) const;
		bool operator[](unsigned int idx);
		int GetIndex(bool findData) const;
		size_t GetSize(void) const;
		size_t GetCapacity(void) const;

		void PrintFixedVector(void) const;

	private:
		int mVector[(N/32)+1];
		size_t mCount;
	};

	template <size_t N>
	FixedVector<bool, N>::FixedVector()
		: mCount(0)
	{
		memset(mVector, 0, sizeof(mVector));
	}

	template <size_t N>
	bool FixedVector<bool, N>::Add(const bool& data)
	{
		if (mCount >= N)
		{
			return false;
		}
		
		mVector[mCount / 32 + ((mCount / 32 + 1) - 1)] |= (data << mCount);
		mCount++;

		return true;
	}

	template <size_t N>
	bool FixedVector<bool, N>::Remove(bool findData)
	{
		bool chkFlag = false;
		size_t findIdx = 0;
		size_t bitIdx = 0;

		if (findData != false)
		{
			for (size_t i = 0; i < (mCount / 32 + 1); i++)
			{
				for (size_t j = 0; j < mCount - ((mCount / 32) * 32); j++)
				{
					if ((mVector[i] & (findData << j)) == (findData << j))
					{
						chkFlag = true;
						findIdx = i;
						bitIdx = j;

						break;
					}
				}
			}
		}
		else
		{
			int tempFalse = 0;

			for (size_t i = 0; i < (mCount / 32 + 1); i++)
			{
				tempFalse = ~mVector[i];

				for (size_t j = 0; j < mCount - ((mCount / 32) * 32); j++)
				{
					if ((tempFalse & (1 << j)) == (1 << j))
					{
						chkFlag = true;
						findIdx = i;
						bitIdx = j;

						break;
					}
				}
			}
		}

		if (chkFlag != false)
		{
			if (findData != false)
			{
				int temp = 0;
				for (size_t i = bitIdx; i < 32; i++)
				{
					temp |= (1 << i);
				}
				
				mVector[findIdx] >>= 1;
				mVector[findIdx] &= temp;

				if ((mCount / 32 + 1) > (findIdx + 1))
				{
					bool tempBit = false;
					for (size_t i = (findIdx + 1); i < (mCount / 32 + 1); i++)
					{
						tempBit = (mVector[i] & (1 << 0));
						mVector[i] >>= 1;
						mVector[i - 1] |= (tempBit << 31);
					}
				}

				mCount--;
			}
			else
			{
				int temp = 0;
				for (size_t i = bitIdx; i < 32; i++)
				{
					temp |= (mVector[findIdx] & (1 << i));
				}
				temp >>= 1;
				
				mVector[findIdx] &= ~(1 << (mCount -1));
				mVector[findIdx] |= temp;

				if ((mCount /32 + 1) > (findIdx + 1))
				{
					bool tempBit = false;

					for (size_t i = (findIdx + 1); i < (mCount / 32 + 1); i++)
					{
						tempBit = (mVector[i] & (1 << 0));
						mVector[i] >>= 1;
						mVector[i - 1] |= (tempBit << 31);
					}
				}

				mCount--;
			}

			return true;
		}
		else
		{
			return false;
		}
	}

	template <size_t N>
	const bool& FixedVector<bool, N>::Get(unsigned int idx) const
	{
		unsigned int findIdx = idx / 32;
		
		return (mVector[findIdx] & (1 << idx));
	}

	template <size_t N>
	bool FixedVector<bool, N>::operator[](unsigned int idx)
	{
		unsigned int findIdx = idx / 32;
		
		return (mVector[findIdx] & (1 << idx));
	}

	template <size_t N>
	int FixedVector<bool, N>::GetIndex(bool findData) const
	{
		bool chkFlag = false;
		size_t findIdx = 0;
		size_t bitIdx = 0;

		if (findData != false)
		{
			for (size_t i = 0; i < (mCount / 32 + 1); i++)
			{
				for (size_t j = 0; j < 32; j++)
				{
					if ((mVector[i] & (findData << j)) == (findData << j))
					{
						chkFlag = true;
						findIdx = i;
						bitIdx = j;

						break;
					}
				}
			}
		}
		else
		{
			int tempFalse = 0;

			for (size_t i = 0; i < (mCount / 32 + 1); i++)
			{
				tempFalse = ~mVector[i];

				for (size_t j = 0; j < 32; j++)
				{
					if ((tempFalse & (1 << j)) == (1 << j))
					{
						chkFlag = true;
						findIdx = i;
						bitIdx = j;

						break;
					}
				}
			}
		}

		if (chkFlag != false)
		{
			return ((findIdx + 1) * 32 + bitIdx);
		}
		else
		{
			return -1;
		}
	}
	
	template <size_t N>
	size_t FixedVector<bool, N>::GetSize(void) const
	{
		if ((mCount / 32 + 1) == 1)
		{
			return mCount;
		}
		else
		{
			return (mCount / 32 + 1) * 32 + (mCount - ((mCount / 32 + 1) * 32));
		}
	}
	template <size_t N>
	size_t FixedVector<bool, N>::GetCapacity(void) const
	{
		return N;
	}


	template <size_t N>
	void FixedVector<bool, N>::PrintFixedVector(void) const
	{
		for (size_t i = 0; i < (mCount / 32 + 1); i++)
		{
			std::cout << std::bitset<32>(mVector[i]) << std::endl;
		}
	}
}